/*!
 * jQuery Once v2.2.3 - http://github.com/robloach/jquery-once
 * @license MIT, GPL-2.0
 *   http://opensource.org/licenses/MIT
 *   http://opensource.org/licenses/GPL-2.0
 */
(function(e){"use strict";if(typeof exports==="object"&&typeof exports.nodeName!=="string"){e(require("jquery"))}else if(typeof define==="function"&&define.amd){define(["jquery"],e)}else{e(jQuery)}})(function(t){"use strict";var r=function(e){e=e||"once";if(typeof e!=="string"){throw new TypeError("The jQuery Once id parameter must be a string")}return e};t.fn.once=function(e){var n="jquery-once-"+r(e);return this.filter(function(){return t(this).data(n)!==true}).data(n,true)};t.fn.removeOnce=function(e){return this.findOnce(e).removeData("jquery-once-"+r(e))};t.fn.findOnce=function(e){var n="jquery-once-"+r(e);return this.filter(function(){return t(this).data(n)===true})}});

;
/**
 * @file
 * Loads the FlexSlider library.
 */

(function ($) {

  'use strict';

  Drupal.behaviors.flexslider = {
    attach: function (context, settings) {
      var sliders = [];
      var id;
      if ($.type(settings.flexslider) !== 'undefined' && $.type(settings.flexslider.instances) !== 'undefined') {

        for (id in settings.flexslider.instances) {

          if (settings.flexslider.instances.hasOwnProperty(id)) {
            if ($.type(settings.flexslider.optionsets) !== 'undefined' && settings.flexslider.instances[id] in settings.flexslider.optionsets) {
              if (settings.flexslider.optionsets[settings.flexslider.instances[id]].asNavFor !== '') {
                // We have to initialize all the sliders which are "asNavFor" first.
                _flexslider_init(id, settings.flexslider.optionsets[settings.flexslider.instances[id]], context);
              }
              else {
                // Everyone else is second.
                sliders[id] = settings.flexslider.optionsets[settings.flexslider.instances[id]];
              }
            }
          }
        }
      }
      // Slider set.
      for (id in sliders) {
        if (sliders.hasOwnProperty(id)) {
          _flexslider_init(id, settings.flexslider.optionsets[settings.flexslider.instances[id]], context);
        }
      }
    }
  };

  /**
   * Initialize the flexslider instance.
   *
   * @param {string} id
   * Id selector of the flexslider object.
   * @param {object} optionset
   * The optionset to apply to the flexslider object.
   * @param {object} context
   * The DOM context.
     * @private
     */
  function _flexslider_init(id, optionset, context) {
    $('#' + id, context).once('flexslider').each(function () {
      // Remove width/height attributes.
      // @todo load the css path from the settings
      $(this).find('ul.slides > li > *').removeAttr('width').removeAttr('height');

      if (optionset) {
        // Add events that developers can use to interact.
        $(this).flexslider($.extend(optionset, {
          start: function (slider) {
            slider.trigger('start', [slider]);
          },
          before: function (slider) {
            slider.trigger('before', [slider]);
          },
          after: function (slider) {
            slider.trigger('after', [slider]);
          },
          end: function (slider) {
            slider.trigger('end', [slider]);
          },
          added: function (slider) {
            slider.trigger('added', [slider]);
          },
          removed: function (slider) {
            slider.trigger('removed', [slider]);
          },
          init: function (slider) {
            slider.trigger('init', [slider]);
          }
        }));
      }
      else {
        $(this).flexslider();
      }
    });
  }

}(jQuery));
;
